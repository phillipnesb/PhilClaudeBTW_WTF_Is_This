
#include <stdint.h>
uint8_t ccp_guard_tool_call(uint64_t currentF, uint64_t currentHarm, uint64_t impactDelta,
                            uint64_t shock, uint64_t B, uint64_t S, uint64_t P,
                            uint64_t fMin, uint64_t hMax, uint64_t xiMax, uint64_t gamma) {
    uint64_t postF = (currentF >= impactDelta) ? (currentF - impactDelta) : 0;
    uint64_t grossHarm = currentHarm + shock;
    uint64_t postHarm = (grossHarm >= gamma) ? (grossHarm - gamma) : 0;
    int gate1 = (fMin <= postF) && (postHarm <= hMax);
    int gate2 = (S <= P);
    int gate3 = (shock <= xiMax);
    return (gate1 && gate2 && gate3) ? 1 : 0;
}
uint64_t ccp_route_aid(uint64_t donorF, uint64_t recipientF, uint64_t shock,
                       uint64_t fMin, uint64_t gamma) {
    uint64_t absorbed = (shock < gamma) ? shock : gamma;
    uint64_t netShock = shock - absorbed;
    uint64_t safeSurplus = (donorF >= fMin) ? (donorF - fMin) : 0;
    uint64_t rawDelta = (donorF >= recipientF + 2) ? ((donorF - recipientF) / 2) : 0;
    uint64_t actualAid = (safeSurplus < rawDelta) ? safeSurplus : rawDelta;
    uint64_t total = recipientF + actualAid;
    return (total >= netShock) ? (total - netShock) : 0;
}
