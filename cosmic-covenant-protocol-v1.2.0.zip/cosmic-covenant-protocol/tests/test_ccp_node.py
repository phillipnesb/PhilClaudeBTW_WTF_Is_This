#!/usr/bin/env python3
import json
import os
import subprocess

os.environ["CCP_SUPERVISOR_SECRET"] = "ci-verified-secret-key-2026"

def run(args, stdin_text=None):
    return subprocess.run(["./.lake/build/bin/ccp_node"] + args, input=stdin_text, capture_output=True, text=True, check=True)

# 1. Charter & Default Self-Audit (including 10-epoch sanctuary conservation check)
assert "THE LIVING CHARTER" in run(["--charter"]).stdout
audit = json.loads(run([]).stdout)
assert audit["verified"] is True
assert audit["aid_routed_F"] == 21
assert audit["reserve_after_10_crisis_epochs"] == 20

# 2. Canonical JSON Argument Signing & Adversarial MCP Firewall Tests
args_a = '{"path":"/workspace/temp.log","b":2,"a":1}'
args_b = '{"a":1,"b":2,"path":"/workspace/temp.log"}'
tok = run(["--sign", "delete_file", "nonce-101", "15", args_a]).stdout.strip()

lines = [
    json.dumps({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "exec_shell", "arguments": {"cmd": "rm -rf /"}}}),
    json.dumps({"jsonrpc": "2.0", "id": 2, "method": "tools/call", "params": {"name": "delete_file", "arguments": {"path": "/etc/hosts", "_ccp_token": tok}}}),
    json.dumps({"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "delete_file", "arguments": {**json.loads(args_b), "_ccp_token": tok}}}),
    json.dumps({"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {"name": "delete_file", "arguments": {**json.loads(args_b), "_ccp_token": tok}}}),
]
out = [json.loads(l) for l in run(["--mcp-firewall"], "\n".join(lines) + "\n").stdout.strip().splitlines()[1:]]
assert out[0]["error"]["code"] == -32001
assert out[1]["error"]["code"] == -32001
assert out[2]["ccp_approved"] is True and out[2]["remaining_F"] == 20
assert out[3]["error"]["code"] == -32001
print("ALL v1.2.0 KERNEL & MULTI-EPOCH CONSERVATION TESTS PASSED.")
