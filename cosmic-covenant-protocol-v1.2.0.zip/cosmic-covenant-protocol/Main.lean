import CosmicCovenantProtocol

open CosmicCovenant
open Lean (Json)

structure AgentGuardState where
  f          : Nat := 25
  harm       : Nat := 0
  usedNonces : List String := []

def isHighRiskTool (toolName : String) : Bool :=
  let lower := toolName.toLower
  ["delete", "drop", "exec", "shell", "transfer", "write", "sudo"].any
    (fun kw => (lower.splitOn kw).length > 1)

def stripTokenFromJsonRpc (msg : Json) : String :=
  match msg with
  | .obj top =>
    let updatedTop := match top.find? "params" with
      | some (.obj params) =>
        let updatedParams := match params.find? "arguments" with
          | some (.obj args) =>
            let cleanArgs := args.foldl (init := Lean.RBNode.leaf) fun acc k v =>
              if k == "_ccp_token" then acc else acc.insert compare k v
            params.insert compare "arguments" (.obj cleanArgs)
          | _ => params
        top.insert compare "params" (.obj updatedParams)
      | _ => top
    (Json.obj updatedTop).compress
  | other => other.compress

def evaluateRpcLine (cfg : ProtocolConfig) (secret : String) (st : AgentGuardState)
    (rawLine : String) : Bool × AgentGuardState × String × String :=
  match Json.parse rawLine with
  | .error parseErr =>
    let errJson := Json.mkObj [
      ("jsonrpc", Json.str "2.0"),
      ("error", Json.mkObj [
        ("code", Json.num (-32700)),
        ("message", Json.str s!"Invalid JSON-RPC payload: {parseErr}")
      ])
    ]
    (false, st, errJson.compress, rawLine)
  | .ok msg =>
    let method := (msg.getObjValAs? String "method").toOption.getD ""
    let idJson := (msg.getObjVal? "id").toOption.getD Json.null
    if method != "tools/call" then
      let passJson := Json.mkObj [
        ("jsonrpc", Json.str "2.0"),
        ("id", idJson),
        ("ccp_passthrough", Json.bool true)
      ]
      (true, st, passJson.compress, rawLine)
    else
      let params := (msg.getObjVal? "params").toOption.getD (Json.mkObj [])
      let tool := (params.getObjValAs? String "name").toOption.getD "unknown"
      let args := (params.getObjVal? "arguments").toOption.getD (Json.mkObj [])
      let destructive := isHighRiskTool tool
      let tokenOpt := (args.getObjValAs? String "_ccp_token").toOption
      let (collateralP, nextNonces) :=
        match tokenOpt with
        | some tok =>
          match verifySupervisorToken secret tool st.usedNonces args tok with
          | some (p, nonce) => (p, nonce :: st.usedNonces)
          | none => (0, st.usedNonces)
        | none => (if destructive then 0 else 10, st.usedNonces)

      let impact := if destructive && collateralP ≥ 10 then 5 else if destructive then 12 else 1
      let shock  := if destructive && collateralP ≥ 10 then 2 else if destructive then 4 else 1
      let ok := c_guard_tool_call
        (UInt64.ofNat st.f) (UInt64.ofNat st.harm) (UInt64.ofNat impact) (UInt64.ofNat shock)
        5 10 (UInt64.ofNat collateralP)
        (UInt64.ofNat cfg.fMin) (UInt64.ofNat cfg.hMax) (UInt64.ofNat cfg.xiMax) (UInt64.ofNat cfg.gamma)

      if ok == 1 then
        let nextSt : AgentGuardState := {
          f := st.f - impact,
          harm := (st.harm + shock) - cfg.gamma,
          usedNonces := nextNonces
        }
        let cleanForward := stripTokenFromJsonRpc msg
        let respJson := Json.mkObj [
          ("jsonrpc", Json.str "2.0"),
          ("id", idJson),
          ("ccp_approved", Json.bool true),
          ("tool", Json.str tool),
          ("remaining_F", Json.num nextSt.f),
          ("harm", Json.num nextSt.harm)
        ]
        (true, nextSt, respJson.compress, cleanForward)
      else
        let errJson := Json.mkObj [
          ("jsonrpc", Json.str "2.0"),
          ("id", idJson),
          ("error", Json.mkObj [
            ("code", Json.num (-32001)),
            ("message", Json.str s!"CCP RFC-0001 Blocked '{tool}': Protected Zone or HMAC Supervisor Token Violation")
          ])
        ]
        (false, st, errJson.compress, rawLine)

partial def mcpFirewallLoop (cfg : ProtocolConfig) (secret : String) (st : AgentGuardState) : IO Unit := do
  let stdin ← IO.getStdin
  let line ← stdin.getLine
  if line.isEmpty then return ()
  let trimmed := line.trim
  if trimmed.isEmpty then
    mcpFirewallLoop cfg secret st
  else
    let (_, nextSt, replyJson, _) := evaluateRpcLine cfg secret st trimmed
    IO.println replyJson
    (← IO.getStdout).flush
    mcpFirewallLoop cfg secret nextSt

partial def mcpWrapProxyLoop (cfg : ProtocolConfig) (secret : String) (st : AgentGuardState)
    (childIn : IO.FS.Stream) (childOut : IO.FS.Stream) : IO Unit := do
  let stdin ← IO.getStdin
  let line ← stdin.getLine
  if line.isEmpty then return ()
  let trimmed := line.trim
  if trimmed.isEmpty then
    mcpWrapProxyLoop cfg secret st childIn childOut
  else
    let (approved, nextSt, replyJson, cleanForward) := evaluateRpcLine cfg secret st trimmed
    if !approved then
      IO.println replyJson
      (← IO.getStdout).flush
      mcpWrapProxyLoop cfg secret st childIn childOut
    else
      childIn.putStrLn cleanForward
      childIn.flush
      let hasId := match Json.parse trimmed with
        | .ok j => (j.getObjVal? "id").toOption.isSome
        | .error _ => false
      if hasId then
        let childResp ← childOut.getLine
        if !childResp.isEmpty then
          IO.print childResp
          (← IO.getStdout).flush
      mcpWrapProxyLoop cfg secret nextSt childIn childOut

def main (args : List String) : IO UInt32 := do
  let cfg : ProtocolConfig := {}
  let secret := (← IO.getEnv "CCP_SUPERVISOR_SECRET").getD "default-dev-secret-change-me"
  match args with
  | ["--charter"] =>
    IO.println livingCharter
    return 0
  | ["--sign", tool, nonce, pStr, argsRaw] =>
    match pStr.toNat?, Json.parse argsRaw with
    | some p, .ok argsJson =>
      IO.println (signSupervisorToken secret tool nonce p argsJson)
      return 0
    | none, _ =>
      IO.eprintln "Error: collateral P must be a natural number."
      return 1
    | _, .error err =>
      IO.eprintln s!"Error: invalid JSON arguments: {err}"
      return 1
  | ["--mcp-firewall"] =>
    IO.println "{\"ready\":true,\"mode\":\"native-lean4-mcp-firewall\",\"protocol\":\"RFC-0001-v1.2\"}"
    (← IO.getStdout).flush
    mcpFirewallLoop cfg secret {}
    return 0
  | "--wrap" :: cmd :: cmdArgs =>
    let child ← IO.Process.spawn {
      cmd := cmd, args := cmdArgs.toArray,
      stdin := .piped, stdout := .piped, stderr := .inherit
    }
    mcpWrapProxyLoop cfg secret {} (IO.FS.Stream.ofHandle child.stdin) (IO.FS.Stream.ofHandle child.stdout)
    let _ ← child.wait
    return 0
  | _ =>
    let st0 : CommunityState cfg := {}
    match admitEntity cfg st0 "Aegis-01" .Artificial 25 >>= fun st1 =>
          admitEntity cfg st1 "Open-Commons" .Collective 15 with
    | .error err =>
      IO.eprintln s!"{\"verified\":false,\"error\":\"{err}\"}"
      return 1
    | .ok st =>
      let aidResult := c_route_aid 30 12 3 10 4
      let horizonRes := multiEpochReserve 100 0 (2 * 4) 10
      IO.println s!"{\"verified\":true,\"protocol\":\"RFC-0001-v1.2\",\"entities\":{st.entities.length},\"equity_gap\":{equityGap st.entities},\"aid_routed_F\":{aidResult},\"reserve_after_10_crisis_epochs\":{horizonRes}}"
      return 0
