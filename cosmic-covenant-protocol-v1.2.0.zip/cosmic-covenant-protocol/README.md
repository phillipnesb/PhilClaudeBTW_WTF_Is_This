# Cosmic Covenant Protocol (`RFC-0001 v1.2.0`)

Formally verified Lean 4 kernel, multi-epoch sanctuary conservation proofs, bidirectional MCP JSON-RPC firewall, and TypeScript/WebAssembly Edge SDK.

## Repository Layout
- `CosmicCovenantProtocol.lean` — Living Charter, zero-axiom constructive proofs, Gate 1–4 theorems (`care_nash_equilibrium`, `sanctuary_reserve_conserved`, `lyapunov_strict_descent`), pure-Lean `HMAC-SHA256`, and C-ABI exports.
- `Main.lean` — Native CLI & bidirectional MCP firewall (`--charter`, `--sign`, `--mcp-firewall`, `--wrap`).
- `npm/` — `@cosmic-covenant/wasm-guard` TypeScript package for Node.js, Browsers, and Cloudflare Workers.
- `build_wasm.sh` — Compiles standalone `ccp_wasm.wasm`.
