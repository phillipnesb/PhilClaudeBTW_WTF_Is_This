# `@cosmic-covenant/wasm-guard` (v1.2.0)

Zero-dependency TypeScript & WebAssembly bindings for the formally verified **Cosmic Covenant Protocol (RFC-0001)**.

## Quick Start (Node.js / Edge / Cloudflare Workers)

```ts
import fs from "node:fs";
import { CosmicCovenantWasmGuard } from "@cosmic-covenant/wasm-guard";

const wasmBytes = fs.readFileSync(new URL("./ccp_wasm.wasm", import.meta.url));
const guard = await CosmicCovenantWasmGuard.fromWasm(wasmBytes);

// Blocks unauthenticated destructive MCP tool call
const decision = guard.handleMcpJsonRpc({
  jsonrpc: "2.0",
  id: 1,
  method: "tools/call",
  params: { name: "exec_shell_command", arguments: { cmd: "rm -rf /" } }
});

console.log(decision.allowed); // false
```
