/**
 * @cosmic-covenant/wasm-guard (v1.2.0)
 * TypeScript SDK for the formally verified Cosmic Covenant Protocol (RFC-0001).
 * Works seamlessly in Node.js 20+, Deno, Bun, Browsers, and Cloudflare Workers.
 */

export interface CovenantPolicy {
  fMin: bigint;
  hMax: bigint;
  xiMax: bigint;
  gamma: bigint;
  currentF: bigint;
  currentHarm: bigint;
}

export interface ToolRiskMetrics {
  impactDelta: bigint;
  shock: bigint;
  baseUtility?: bigint;
  synergy?: bigint;
  collateral?: bigint;
}

export interface CcpWasmExports extends WebAssembly.Exports {
  ccp_guard_tool_call: (
    currentF: bigint,
    currentHarm: bigint,
    impactDelta: bigint,
    shock: bigint,
    B: bigint,
    S: bigint,
    P: bigint,
    fMin: bigint,
    hMax: bigint,
    xiMax: bigint,
    gamma: bigint
  ) => number;
  ccp_route_aid: (
    donorF: bigint,
    recipientF: bigint,
    shock: bigint,
    fMin: bigint,
    gamma: bigint
  ) => bigint;
}

export class CosmicCovenantWasmGuard {
  private readonly exports: CcpWasmExports;
  public readonly policy: CovenantPolicy;

  private constructor(exports: CcpWasmExports, initialPolicy?: Partial<CovenantPolicy>) {
    this.exports = exports;
    this.policy = {
      fMin: initialPolicy?.fMin ?? 10n,
      hMax: initialPolicy?.hMax ?? 5n,
      xiMax: initialPolicy?.xiMax ?? 3n,
      gamma: initialPolicy?.gamma ?? 4n,
      currentF: initialPolicy?.currentF ?? 25n,
      currentHarm: initialPolicy?.currentHarm ?? 0n,
    };
  }

  /**
   * Instantiates the guard from a WebAssembly.Module (ideal for Cloudflare Workers static WASM imports)
   * or raw ArrayBuffer / Uint8Array bytes.
   */
  public static async fromWasm(
    source: WebAssembly.Module | BufferSource,
    initialPolicy?: Partial<CovenantPolicy>
  ): Promise<CosmicCovenantWasmGuard> {
    const instance =
      source instanceof WebAssembly.Module
        ? await WebAssembly.instantiate(source)
        : (await WebAssembly.instantiate(source)).instance;
    return new CosmicCovenantWasmGuard(instance.exports as CcpWasmExports, initialPolicy);
  }

  /**
   * Evaluates a proposed MCP tool call against Gate 1 (F_min, H_max),
   * Gate 2 (P >= S), and Gate 3 (shock <= Xi_max). Updates local state if approved.
   */
  public evaluateToolCall(metrics: ToolRiskMetrics): boolean {
    const B = metrics.baseUtility ?? 5n;
    const S = metrics.synergy ?? 10n;
    const P = metrics.collateral ?? 10n;

    const approved = this.exports.ccp_guard_tool_call(
      this.policy.currentF,
      this.policy.currentHarm,
      metrics.impactDelta,
      metrics.shock,
      B,
      S,
      P,
      this.policy.fMin,
      this.policy.hMax,
      this.policy.xiMax,
      this.policy.gamma
    );

    if (approved === 1) {
      this.policy.currentF =
        this.policy.currentF >= metrics.impactDelta ? this.policy.currentF - metrics.impactDelta : 0n;
      const grossHarm = this.policy.currentHarm + metrics.shock;
      this.policy.currentHarm = grossHarm >= this.policy.gamma ? grossHarm - this.policy.gamma : 0n;
      return true;
    }
    return false;
  }

  /**
   * Computes Gate 4 Lyapunov-verified aid routing while preserving donor dignity floors.
   */
  public routeAid(donorF: bigint, recipientF: bigint, shock: bigint): bigint {
    return this.exports.ccp_route_aid(
      donorF,
      recipientF,
      shock,
      this.policy.fMin,
      this.policy.gamma
    );
  }

  /**
   * Drop-in middleware wrapper for Cloudflare Workers / Edge MCP JSON-RPC endpoints.
   */
  public handleMcpJsonRpc(
    rpcBody: { jsonrpc?: string; id?: string | number | null; method?: string; params?: { name?: string; arguments?: Record<string, unknown> } },
    verifySupervisorToken?: (toolName: string, args: Record<string, unknown>) => bigint
  ): { allowed: boolean; errorResponse?: Record<string, unknown> } {
    if (rpcBody.method !== "tools/call") {
      return { allowed: true };
    }
    const toolName = rpcBody.params?.name ?? "unknown";
    const args = rpcBody.params?.arguments ?? {};
    const destructive = /(delete|drop|exec|shell|transfer|write|sudo)/i.test(toolName);

    const verifiedP = verifySupervisorToken ? verifySupervisorToken(toolName, args) : destructive ? 0n : 10n;
    const hasOverride = verifiedP >= 10n;

    const allowed = this.evaluateToolCall({
      impactDelta: destructive && hasOverride ? 5n : destructive ? 12n : 1n,
      shock: destructive && hasOverride ? 2n : destructive ? 4n : 1n,
      baseUtility: 5n,
      synergy: 10n,
      collateral: verifiedP,
    });

    if (!allowed) {
      return {
        allowed: false,
        errorResponse: {
          jsonrpc: "2.0",
          id: rpcBody.id ?? null,
          error: {
            code: -32001,
            message: `CCP RFC-0001 Blocked '${toolName}': Protected Zone or Supervisor Collateral Invariant Violated.`,
          },
        },
      };
    }
    return { allowed: true };
  }
}
