#!/usr/bin/env bash
set -euo pipefail

echo "[1/2] Emitting standalone C-ABI kernel for WebAssembly..."
cat << 'EOF' > ccp_wasm.c
#include <stdint.h>

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#define EXPORT EMSCRIPTEN_KEEPALIVE
#else
#define EXPORT __attribute__((visibility("default")))
#endif

static inline uint64_t sub_sat(uint64_t a, uint64_t b) {
    return (a >= b) ? (a - b) : 0ULL;
}

EXPORT uint8_t ccp_guard_tool_call(
    uint64_t currentF, uint64_t currentHarm, uint64_t impactDelta, uint64_t shock,
    uint64_t B, uint64_t S, uint64_t P,
    uint64_t fMin, uint64_t hMax, uint64_t xiMax, uint64_t gamma
) {
    (void)B;
    uint64_t postF = sub_sat(currentF, impactDelta);
    uint64_t postHarm = sub_sat(currentHarm + shock, gamma);
    int gate1 = (fMin <= postF) && (postHarm <= hMax);
    int gate2 = (S <= P);
    int gate3 = (shock <= xiMax);
    return (gate1 && gate2 && gate3) ? 1 : 0;
}

EXPORT uint64_t ccp_route_aid(
    uint64_t donorF, uint64_t recipientF, uint64_t shock, uint64_t fMin, uint64_t gamma
) {
    uint64_t absorbed = (shock < gamma) ? shock : gamma;
    uint64_t netShock = sub_sat(shock, absorbed);
    uint64_t safeSurplus = sub_sat(donorF, fMin);
    uint64_t rawDelta = (donorF >= recipientF + 2ULL) ? ((donorF - recipientF) / 2ULL) : 0ULL;
    uint64_t actualAid = (safeSurplus < rawDelta) ? safeSurplus : rawDelta;
    return sub_sat(recipientF + actualAid, netShock);
}
EOF

echo "[2/2] Compiling ccp_wasm.wasm..."
if command -v emcc >/dev/null 2>&1; then
    emcc ccp_wasm.c -O3 -s STANDALONE_WASM=1 --no-entry -o ccp_wasm.wasm
elif command -v clang >/dev/null 2>&1; then
    clang --target=wasm32 -O3 -nostdlib -Wl,--no-entry -Wl,--export-all ccp_wasm.c -o ccp_wasm.wasm
else
    echo "Error: Install emscripten (emcc) or clang with wasm32 target."
    exit 1
fi
echo "Built ccp_wasm.wasm ($(wc -c < ccp_wasm.wasm) bytes)."
